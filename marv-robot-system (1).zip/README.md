# MARV Robot Control System

A lightweight, high-performance AI robot control framework inspired by advanced architectures like Grok + Optimus.

## Features
- **High-level planning** (System 2 reasoning)
- **Low-latency execution** (System 1 real-time control)
- Async-first design for maximum speed
- Task queuing, sensing, retries, and logging
- Easy to extend with real hardware, vision, or LLMs

## Quick Start
```bash
pip install asyncio  # (built-in)
python marv_robot_system.py
```

## Project Structure
- `marv_robot_system.py` - Core control system
- `LICENSE` - MIT License
- `README.md` - This file

## License
MIT - Free to use, modify, and distribute.

Built with ❤️ for the future of robotics.
